from tkinter import Button, Tk, Label, Entry

"""def valider_saisie(event):
    texte_saisi = entree.get()  # Récupérer le texte saisi
    if "@" in texte_saisi and " " not in texte_saisi and "." in texte_saisi:
        label.config(text="Saisie valide")
        print("Adresse Email saisie :", texte_saisi)
        window.destroy()
    else:
        label.config(text="Saisie non valide")

window = Tk()
window.configure(background="light green", borderwidth=3)
window.title("Veuillez entrer votre Email :")

label = Label(window, text="Veuillez entrer votre Email :", bg="light green", borderwidth=3)
label.pack()

entree = Entry(window, bg="light green", borderwidth=3)
entree.pack()

entree.bind("<KeyRelease>", valider_saisie)  # Associer la fonction de validation à l'événement KeyRelease de 'entree'

boutonValider = Button(window, text="Valider", bg="light green", borderwidth=3)
boutonValider.pack()

window.mainloop()"""
