import tkinter 
from tkinter import *
from PIL import Image, ImageTk
from tkinter.simpledialog import askstring


# -------- Fonction des boutons --------

def switch_action():
    global switch_actif, routeur_actif, pc_actif, supprimer_actif, select_actif
    switch_actif = not switch_actif
    routeur_actif, pc_actif, supprimer_actif, select_actif = False, False, False, False

def routeur_action():
    global switch_actif, routeur_actif, pc_actif, supprimer_actif, select_actif
    routeur_actif = not routeur_actif
    pc_actif, switch_actif, supprimer_actif, select_actif = False, False, False, False

def pc_action():
    global switch_actif, routeur_actif, pc_actif, supprimer_actif, select_actif
    switch_actif, supprimer_actif, routeur_actif, select_actif = False, False, False, False
    pc_actif = not pc_actif

def supprimer_action():
    global supprimer_actif, switch_actif, routeur_actif, pc_actif, select_actif
    pc_actif, switch_actif, routeur_actif, select_actif = False, False, False, False
    supprimer_actif = not supprimer_actif
    item_a_deplacer = None
    
def supprimer_objet_select():
    global item_a_deplacer
    if item_a_deplacer:
        canvas.delete(item_a_deplacer)
        item_a_deplacer = None

def select_action():
    global supprimer_actif, switch_actif, routeur_actif, pc_actif, select_actif
    pc_actif, switch_actif, routeur_actif, supprimer_actif = False, False, False, False
    select_actif = not select_actif

def creer_lien():
    global lien_en_cours, objets_connectes
    lien_en_cours = True
    objets_connectes = []

def modifier_nom():
    global item_a_deplacer
    item_a_deplacer = None

clavier_actions = {"C": pc_action, "S": switch_action, "R": routeur_action}

# fonction de raccourcis clavier
def on_key_press(event):
    key = event.char.upper()
    if key in clavier_actions:
        clavier_actions[key]()


# Def des clics, quand un bouton actif, les autres inactifs, bouton suppr supprime l'item le plus proche

def on_canvas_click(event):
    global switch_actif, routeur_actif, pc_actif, supprimer_actif, select_actif, link_actif, objets_connectes
    if switch_actif:
            x, y = event.x, event.y
            canvas.create_image(x, y, image=icone_switch, anchor="nw")
            routeur_actif, pc_actif, supprimer_actif, select_actif = False, False, False, False
    elif routeur_actif:
            x, y = event.x, event.y
            canvas.create_image(x, y, image=icone_routeur, anchor="nw")
            switch_actif, pc_actif, supprimer_actif, select_actif = False, False, False, False
    elif pc_actif:
            x, y = event.x, event.y
            canvas.create_image(x, y, image=icone_pc, anchor="nw")
            switch_actif, routeur_actif, supprimer_actif, select_actif = False, False, False, False
    elif supprimer_actif:
            switch_actif, routeur_actif, pc_actif, select_actif = False, False, False, False
            item = canvas.find_closest(event.x, event.y)
            if item:
                canvas.delete(item)
    elif select_actif:
            item_a_deplacer = canvas.find_closest(event.x, event.y)
            if item_a_deplacer:
                # Associer la fonction de déplacement au clic de la souris
                canvas.tag_bind(item_a_deplacer, "<B1-Motion>", lambda e: deplacer(e, item_a_deplacer))
    elif link_actif:
        item = canvas.find_closest(event.x, event.y)
        if item:
            objets_connectes.append(item[0])
            if len(objets_connectes) == 2:
                # Créer un lien entre les deux objets (ajustez selon votre logique)
                canvas.create_line(canvas.coords(objets_connectes[0]), canvas.coords(objets_connectes[1]), fill="black")
                objets_connectes = []
                link_actif = False

def on_canvas_press(event):
    global select_actif, item_a_deplacer
    if select_actif:
        item_a_deplacer = canvas.find_closest(event.x, event.y)
        if item_a_deplacer:
            canvas.tag_bind(item_a_deplacer, "<B1-Motion>", lambda e: deplacer(e, item_a_deplacer))# associer déplacement au clic de la souris

def on_canvas_release(event):
    global item_a_deplacer
    if item_a_deplacer:
        # Dissocier la fonction de déplacement lorsque le bouton est relâché
        canvas.tag_unbind(item_a_deplacer, "<B1-Motion>")
        item_a_deplacer = None  

def deplacer(event, item_id):
    canvas.coords(item_id, event.x, event.y)

# ------- Init boutons à l'état inactif --------

def clicDroit(event):
    global item_a_deplacer
    item_a_deplacer = canvas.find_closest(event.x, event.y)
    if item_a_deplacer:
        item_properties_menu = Menu(window, tearoff=0)
        item_properties_menu.add_command(label="Modifier le nom", command=modifier_nom)
      #  item_properties_menu.add_command(label="Modifier l'icône", command=modifier_icone)
        item_properties_menu.post(event.x_root, event.y_root)

switch_actif = False
routeur_actif = False
pc_actif = False
supprimer_actif = False
select_actif = False
item_a_deplacer = None

window = Tk()
window.configure(background="light blue", borderwidth=6)
window.geometry("1300x1000")
window.title("Pisco Paquet Pracer")

# Canevas pour les boutons
canvasBoutons = Canvas(window, width=120, height=700, bg="light blue")
canvasBoutons.grid(row=0, column=0, rowspan=6, sticky="nsew")

# Bouton switch
imageSwitch = Image.open("images/switch.png").resize((70, 70))
icone_switch = ImageTk.PhotoImage(imageSwitch)
switch = Button(canvasBoutons, image=icone_switch, command=switch_action)
switch.grid(row=1, column=0, sticky="nsew")

# Bouton routeur
imageRouteur = Image.open("C://Users/mazzo/OneDrive/Bureau/COURS RT/2emeAnnee/S3/R309/images/router.png").resize((70, 70))
icone_routeur = ImageTk.PhotoImage(imageRouteur)
routeur = Button(canvasBoutons, image=icone_routeur, command=routeur_action)
routeur.grid(row=2, column=0, sticky="nsew")

# Bouton PC
imagePC = Image.open("C://Users/mazzo/OneDrive/Bureau/COURS RT/2emeAnnee/S3/R309/images/pc.png").resize((70, 70))
icone_pc = ImageTk.PhotoImage(imagePC)
pc = Button(canvasBoutons, image=icone_pc, command=pc_action)
pc.grid(row=3, column=0, sticky="nsew")

# Bouton Link
imageLink = Image.open("C://Users/mazzo/OneDrive/Bureau/COURS RT/2emeAnnee/S3/R309/images/link.png").resize((70, 70))
icone_link = ImageTk.PhotoImage(imageLink)
link = Button(canvasBoutons, image=icone_link, command=creer_lien)
link.grid(row=4, column=0, sticky="nsew")

# Bouton Suppr
imageSuppr = Image.open("C://Users/mazzo/OneDrive/Bureau/COURS RT/2emeAnnee/S3/R309/images/suppr.png").resize((70, 70))
icone_suppr = ImageTk.PhotoImage(imageSuppr)
suppr = Button(canvasBoutons, image=icone_suppr, command=supprimer_action)
suppr.grid(row=5, column=0, sticky="nsew")

# Bouton Select
imageCurseur = Image.open("C://Users/mazzo/OneDrive/Bureau/COURS RT/2emeAnnee/S3/R309/images/curseur.png").resize((70, 70))
icone_Curseur = ImageTk.PhotoImage(imageCurseur)
select = Button(canvasBoutons, image=icone_Curseur, command=select_action)
select.grid(row=6, column=0, sticky="nsew")

# Canevas blanc pour les objets
canvas = Canvas(window, width=1400, height=1000, bg="white")
canvas.grid(row=0, column=1, rowspan=6, sticky="nsew")

# Lier le clic de la souris à la fonction on_canvas_click
canvas.bind("<Button-1>", on_canvas_click)

# Associer la fonction de déplacement au clic de la souris
# canvas.bind("<B1-Motion>", on_canvas_drag)

# clic droit
canvas.bind("<Button-3>", clicDroit)

# touches du clavier
window.bind("<Key>", on_key_press)


# Ajouter un Label pour afficher le texte
label_text = StringVar()
label_text.set("Cliquez sur un bouton")
label = Label(window, textvariable=label_text)
label.grid(row=6, column=0, columnspan=2, sticky="nsew")


window.mainloop()