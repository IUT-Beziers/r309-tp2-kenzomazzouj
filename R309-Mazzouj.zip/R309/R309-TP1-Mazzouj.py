from tkinter import Button, Tk, Label, IntVar as tk


def increment():
    x.set(x.get() + 1)

def decrement():
    x.set(x.get() - 1)

window = tk()
window.title("Incrémenter et Décrémenter")

x = tk.IntVar()
x.set(0)

label = tk.Label(window, textvariable=x)
label.pack()

boutonPlus = tk.Button(window, text="+", command=increment)
boutonMoins = tk.Button(window, text="-", command=decrement)

boutonPlus.pack()
boutonMoins.pack()

window.mainloop()
